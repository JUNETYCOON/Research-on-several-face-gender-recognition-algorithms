import numpy as np
from heamy.dataset import Dataset
from heamy.estimator import Regressor, Classifier
from heamy.pipeline import ModelsPipeline
from sklearn.ensemble import AdaBoostRegressor
from matplotlib import pyplot as plt
from sklearn import model_selection, decomposition
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import mean_absolute_error, confusion_matrix, accuracy_score, precision_score, recall_score, \
    f1_score, roc_auc_score, roc_curve
#加载数据集
from sklearn.datasets import load_boston

from func import mblbp

print('stacking')
x, y = mblbp()

 # PCA降维————————————————————————————————————————————————————————————————
# pca = decomposition.PCA()
# pca.fit(x)
# # 观察占比可以选择降多少维
# print(pca.explained_variance_ratio_)
# # X为降维后数据
# X = pca.fit_transform(x)
# print(X)

# stdsc = StandardScaler()  # 标准化
# X = stdsc.fit_transform(x)

# from func import match_PicGen
#
# x, y = match_PicGen("./rawdata", 'faceDR', 'faceDS')  # 读取文件夹下的文件

X_train, X_test, y_train, y_test = model_selection.train_test_split(x, y, test_size=0.1, random_state=111)
#创建数据集
dataset = Dataset(X_train,y_train,X_test)
#创建RF模型和LR模型
model_rf = Regressor(dataset=dataset, estimator=RandomForestRegressor, parameters={'n_estimators': 100},name='rf')
model_ab = Regressor(dataset=dataset, estimator=AdaBoostRegressor, parameters={'n_estimators': 50},name='ab')
model_lr = Regressor(dataset=dataset, estimator=LinearRegression, parameters={'normalize': True},name='lr')
# Stack两个模型
# Returns new dataset with out-of-fold predictions
pipeline = ModelsPipeline( model_ab, model_lr)
stack_ds = pipeline.stack(k=10,seed=111)
#第二层使用lr模型stack
stacker = Classifier(dataset=stack_ds, estimator=SVC, parameters={'probability': True})
results = stacker.predict()
# 使用10折交叉验证结果
results10 = stacker.validate(k=10, scorer=mean_absolute_error)
# print('result')
# print(results10)
# y_hat = stacker.predict()
# y_score = stacker.decision_function(X_test)
# #
# # # -------------------------------------------------------------------------------
# print("混淆矩阵：")
# print(confusion_matrix(y_test, y_hat))
# print("准确率：", accuracy_score(y_test, y_hat))
# print("精确率：", precision_score(y_test, y_hat, pos_label=1, average='binary'))
# print("召回率：", recall_score(y_test, y_hat, pos_label=1, average='binary'))
# print("F1值：", f1_score(y_test, y_hat, pos_label=1, average='binary'))
# #
# y = np.array(y_test)
# print("AUC值：", roc_auc_score(y, y_score))
# fpr, tpr, thresholds = roc_curve(y, y_score, pos_label=1)
# plt.figure(figsize=(5, 5))
# plt.plot(fpr, tpr, color='darkorange',
#          label='ROC curve (area = %0.2f)' % roc_auc_score(y, y_score))  ###假正率为横坐标，真正率为纵坐标做曲线
# plt.plot([0, 1], [0, 1], color='navy', linestyle='--')
# plt.xlim([0.0, 1.0])
# plt.ylim([0.0, 1.05])
# plt.xlabel('False Positive Rate')
# plt.ylabel('True Positive Rate')
# plt.title('Receiver operating characteristic curve')
# plt.legend(loc="lower right")
# plt.show()
